﻿
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "finitefield.h"
#include "extensions.h"
#include <time.h>
#include <unistd.h>
#include <sys/time.h>
#include "x86estimate.h"



bigInteger coef1[NFp];
bigInteger coef2[NFp];
bigInteger res[NFp];
// global variable 
bigInteger p; //prime p
bigInteger b;
#define NFp 2
bigInteger A0[NFp];
bigInteger A1[NFp];
bigInteger V0[NFp];














int main(int argc,char **argv)
{

  long long t[1001];

 // 255 to 600
	char s1[600],s2[600];
	//char* re = CreateArray(255); 
  
  srand((unsigned)time(NULL));  // Initialization function of random number generator
  
  bigInteger k1,k2,k3;

  /* test the readradix is correct or not
  bigIntInitial(&p);
  bigIntReadRadix(&p,  "218297830370226601612193514776502382704221475011035725792624279635059316315225569375126760584265176077347911285544462735949991646330887",  10);
  //bigIntReadRadix(&p,  "5",  10);
*/
  passModPrime();

 

  int l = bigIntCountBits(&p);
  printf("the bit is %d \n ", l);

  bigIntInitial(&k1);
  
  printf("please input your random integer a\n");
  gets(s1);
  bigIntReadRadix(&k1,  s1,  10);


  correctnessNew(&k1,&p);

	getchar();
  

   return 0;

}










